﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace genericCountMethodStrings
{
    public class Program
    {
        static void Main(string[] args)
        {
            var linesCount = int.Parse(Console.ReadLine());
            var list = new List<string>();
            for (int i = 0; i < linesCount; i++)
            {
                var value = Console.ReadLine();

                list.Add(value);
            }
            var box = new Box<string>(list);
            var toCompare = Console.ReadLine();

            Console.WriteLine(box.ComparerByValue(box.List,toCompare));
        }

    }
}
